import router from './router'
import store from './store'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import {getToken, setToken} from '@/utils/auth' // get token from cookie
import {ReturnWechat, GetUserInfo} from '@/api/api'
NProgress.configure({showSpinner: false}) // NProgress Configuration

const whiteList = store.getters.whiteList

router.beforeEach(async (to, from, next) => {
  NProgress.start()
  const hasToken = getToken()
  if (hasToken) {
    // 已登录
    if (to.path === '/login') {
      next({path: '/'})
      // NProgress.done()
    } else {
      next()
    }
  } else {
    // 未登录
    if (whiteList.indexOf(to.path) !== -1) {
      next()
    } else {
      // next(`/login?redirect=${to.path}`)
      // alert('需要登录')
      console.log('拦截')
      const loactionUrl = 'http://www.m22opt.com' + to.fullPath
      console.log(to, from, loactionUrl)

      const code = to.query.code
      if (code) {
        GetUserInfo({code: code})
          .then((res) => {
            console.log(res)
            const id = res.ID
            setToken(id)
            next() //! 打开开放
          })
          .catch((err) => {
            this.$dialog
              .confirm({
                title: '',
                message: err
              })
              .then(() => {
                window.location.reload()
              })
              .catch(() => {})
            alert(err)
          })
      } else {
        // 获取code
        ReturnWechat({url: loactionUrl})
          .then((res) => {
            window.location.href = res
          })
          .catch((err) => {
            alert('登录失败稍候重试！')
          })
      }

      // console.log('需要登录')

      // console.log(code)
      // next() //!打包删
      // NProgress.done()
    }
  }
})

router.afterEach(() => {
  // store.commit('app/SET_PAGEINIT', true)
  // finish progress bar
  NProgress.done()
})
function cutUrl(codestr, name) {
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
  var r = window.location.search.substr(1).match(reg)
  if (r != null) {
    return decodeURI(r[2])
  }
  return null
}
