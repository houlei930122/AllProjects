<template>
  <van-swipe :autoplay="autoplay">
    <van-swipe-item v-for="(item, index) in list" :key="index">
      <slot :item="item">
        <van-image :src="item.imgUrl" lazy-load :style="defaultStyle" />
      </slot>
    </van-swipe-item>
  </van-swipe>
</template>

<script>
import { Swipe, SwipeItem } from 'vant'
export default {
  name: 'Swipe',
  components: {
    [Swipe.name]: Swipe,
    [SwipeItem.name]: SwipeItem
  },
  props: {
    list: {
      type: Array,
      default() {
        return []
      }
    },
    defaultStyle: {
      type: Object,
      default() {
        return {}
      }
    },
    autoplay: {
      type: [String, Number],
      default() {
        return '-'
      }
    }
  }
}
</script>
