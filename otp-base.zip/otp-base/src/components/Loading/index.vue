<template>
  <van-loading vertical>加载中...</van-loading>
</template>

<script>
// 页面级loading
export default {
  name: 'Loading'
}
</script>

<style scoped lang="less">
.van-loading--vertical {
  justify-content: center;
}
.van-loading {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 10000;
  background: #fff;
}
</style>
