import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/* Router Modules */

/**
 * constantRoutes
 * 没有权限要求的基本页
 * 所有角色均可访问
 */
export const constantRouterMap = [
  // 登录
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/login/index'),
    meta: {title: '登录'}
  },
  {
    path: '/exam',
    name: 'Name',
    component: () => import('@/views/exam/index'),
    meta: {title: '测测你的"干眼程度"'}
  },
  {
    path: '/examnew',
    name: 'Name',
    component: () => import('@/views/exam/index'),
    meta: {title: '测测你的"干眼程度"'}
  },
  {
    path: '/exam1',
    name: 'Name1',
    component: () => import('@/views/exam1/index'),
    meta: {title: '测测你的"干眼程度"'}
  },
  {
    path: '/subscribe',
    name: 'Subscribe',
    component: () => import('@/views/subscribe/index'),
    meta: {title: '预约治疗'}
  },
  {
    path: '/hospital',
    name: 'Hospital',
    component: () => import('@/views/hospital/index'),
    meta: {title: '医院介绍'}
  },
  {
    path: '/diary',
    name: 'Diary',
    component: () => import('@/views/diary/index'),
    meta: {title: '日记'}
  },
  {
    path: '/sumdiary',
    name: 'Sumdiary',
    component: () => import('@/views/sumdiary/index'),
    meta: {title: '医院日记'}
  },
  {
    path: '/hospitallist',
    name: 'Hospitallist',
    component: () => import('@/views/hospitallist/index'),
    meta: {title: '查询医院'}
  },
  {
    path: '/edit',
    name: 'Edit',
    component: () => import('@/views/edit/index'),
    meta: {title: '编辑日记', roles: true}
  },
  {
    path: '/mydiary',
    name: 'Mydiary',
    component: () => import('@/views/mydiary/index'),
    meta: {title: '我的日记', roles: true}
  },

  // 一级页面
  {
    path: '/',
    redirect: '/exam'
  },
  // {
  //   path: '/',
  //   name: 'Home',
  //   component: () => import('@/views/home/index'),
  //   meta: { title: '首页' }
  // },
  // {
  //   path: '/mine',
  //   name: 'Mine',
  //   component: () => import('@/views/mine/index'),
  //   meta: { title: '我的', roles: true }
  // },
  {
    path: '/404',
    name: '404',
    component: () => import('@/views/error/404'),
    meta: {title: '404'}
  },
  // 404 页面必须放在最后面
  {path: '*', redirect: '/404', hidden: true}
]

export const asyncRouterMap = []

const createRouter = () =>
  new Router({
    mode: 'history', // require service support
    routes: constantRouterMap,
    scrollBehavior(to, from, savedPosition) {
      if (savedPosition) {
        return savedPosition
      } else {
        return {
          x: 0,
          y: 0
        }
      }
    }
  })

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
