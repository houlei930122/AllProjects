const state = {
  pageInit: false, // 页面是否初次打开
  loadingNum: 0 // 全局loading请求数量
}

const mutations = {
  SET_PAGEINIT: (state, pageInit) => {
    state.pageInit = pageInit
  },
  SET_LOADINGNUM: (state, num) => {
    state.loadingNum += num
  }
}

const actions = {}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
