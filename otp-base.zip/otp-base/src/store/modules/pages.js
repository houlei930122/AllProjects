import { getHomeTabbar } from '@/api/home/index'
import { isEmpty } from '@/utils'

const state = {
  homeTabbars: [] // 首页底部标签栏数据
}

const mutations = {
  SET_HOMETABBARS: (state, homeTabbars) => {
    state.homeTabbars = homeTabbars
  }
}

const actions = {
  // 获取首页标签栏数据
  getHomeTabbars({ commit, state }) {
    if (!isEmpty(state.homeTabbars)) {
      return new Promise((resolve, reject) => {
        getHomeTabbar()
          .then((response) => {
            commit('SET_HOMETABBARS', response.data)
            resolve()
          })
          .catch((error) => {
            reject(error)
          })
      })
    }
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
