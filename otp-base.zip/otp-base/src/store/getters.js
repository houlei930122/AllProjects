const getters = {
  pageInit: state => state.app.pageInit,
  loadingNum: state => state.app.loadingNum,
  token: state => state.user.token,
  name: state => state.user.name,
  userId: state => state.user.userId,
  menus: state => state.user.menus,
  whiteList: state => state.permission.whiteList,
  permission_routers: state => state.permission.routers,
  addRouters: state => state.permission.addRouters,
  homeTabbars: state => state.pages.homeTabbars
}
export default getters
