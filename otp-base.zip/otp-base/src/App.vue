<template>
  <div id="app">
    <keep-alive :include="includeList">
      <router-view :key="key" />
    </keep-alive>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'App',
  computed: {
    key() {
      return this.$route.path
    },
    ...mapState({
      includeList: state => state.permission.includeList
    })
  }
}
</script>

<style lang="less"></style>
