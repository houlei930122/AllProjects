<template>
  <div class="wrap">
    <div class="sum-tit"></div>
    <div class="container">
      <div class="diary-wrap">
        <div class="diary-content">
          <div class="diary-tit1">
            <img src="@/assets/images/mydiary-tit.png" alt="" srcset="" />
          </div>
          <div class="diary-list" v-if="diaryList.length > 0">
            <div class="diary-item" v-for="item in diaryList" :key="item.ID" @click="godiary(item.ID)">
              <div class="item-h">
                <img v-if="item.ImgPath" :src="resetUrl(item.ImgPath)" alt="" />
                <img v-else src="http://admin.m22opt.com/images/suoluetu.png" alt="" />
              </div>
              <div class="diary-msg">
                <div class="diary-tit van-ellipsis">{{ item.Title }}</div>
                <div class="diary-con van-multi-ellipsis--l3">{{ item.Remark }}</div>
              </div>
            </div>
          </div>
          <!-- 暂无数据 -->
          <div class="nodata" v-else>
            <div class="nodata-con">
              <img src="@/assets/images/nodata.png" alt="" />
              <div class="nodata-msg">暂无日志<br />速来分享治疗体验</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <router-link :to="{path: '/edit'}" class="goedit"></router-link>
  </div>
</template>

<script>
import {GetNewsListByMem} from '../../api/api'
import {getToken, setToken} from '@/utils/auth' //
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      diaryList: []
    }
  },
  computed: {},
  watch: {},
  created() {
    const memberid = getToken()
    GetNewsListByMem({memberid}).then((res) => {
      console.log(res)
      this.diaryList = res
    })
    const linkUrl = window.location.href
    shareFun('OPT干眼治疗中心干眼日记', '分享治疗体验，为医院和专家打call', 'http://admin.m22opt.com/images/riji.png', linkUrl)
  },
  mounted() {},
  methods: {
    // 查看日记
    godiary(id) {
      console.log(id)
      this.$router.push({
        path: '/diary',
        query: {id: id}
      })
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
