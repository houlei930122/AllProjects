<template>
  <div class="wrap">
    <div class="container">
      <div class="sum-tit"></div>
      <div class="header-img">
        <img src="@/assets/images/banner.png" alt="" srcset="" />
      </div>
      <div class="header-msg">
        <div class="msg-content">OPT干眼治疗中心为全国各地医院围绕M22王者之EYE干眼治疗系统设立，致力为广大群众提供全面、定制、安全有效的干眼治疗服务</div>
      </div>
      <div class="btn-wrap">
        <router-link :to="{path: '/sumdiary'}" class="btn"><img src="@/assets/images/diary-btn.png" alt="" srcset=""/></router-link>
        <router-link :to="{path: '/exam'}" class="btn"><img src="@/assets/images/h5-btn.png" alt="" srcset=""/></router-link>
      </div>

      <div class="diary-wrap">
        <div class="diary-content">
          <div class="diary-hospital">
            <div class="hospital-select">
              <van-field class="vanfield1" v-model="hosVal" readonly @click="showHos = true" />
            </div>
            <!-- <div class="hospital-select">
              <van-dropdown-menu>
                <van-dropdown-item v-model="city" :options="cityarr" />
              </van-dropdown-menu>
            </div> -->
          </div>
          <div class="diary-list" v-if="hostPitalList.length > 0">
            <div class="diary-item" v-for="item in hostPitalList" :key="item.ID">
              <div class="item-h"><img :src="resetUrl(item.Logo)" alt="" /></div>
              <div class="diary-msg">
                <div class="diary-tit ">{{ item.Name }}</div>
                <div class="diary-con ">地址：{{ item.Address }}</div>
                <div class="dirary-tel">
                  <span class="tel"
                    >咨询电话: <a :href="'tel:' + item.TelePhone">{{ item.TelePhone }}</a>
                  </span>
                  <span class="getmore" @click="goHos(item.ID)">查看更多 ></span>
                </div>
              </div>
            </div>
          </div>
          <!-- 暂无数据 -->
          <div class="nodata" v-else>
            <div class="nodata-con">
              <img src="@/assets/images/nodata.png" alt="" />
              <div class="nodata-msg">暂无日志<br />速来分享治疗体验</div>
              <router-link :to="{path: '/edit'}" class="goedit">我要写</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
    <van-popup v-model="showHos" round position="bottom">
      <van-cascader v-model="hosid" title="请选择医院" :options="hosarr" @close="showHos = false" @finish="onFinishHospitalid" />
    </van-popup>
  </div>
</template>

<script>
import {GetHospitalPicList, GetCityList, GetHostpitalListByAddr, GetHostpitalListByLatLng, GetHostPitalList, GetProvinceList, GetCityDataJson} from '../../api/api'
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      showHos: false,
      hosVal: '', //城市名字
      hosid: '', // 省市id
      hosarr: [],
      hostPitalList: []
    }
  },
  computed: {},

  async created() {
    const linkUrl = window.location.href
    shareFun('全国OPT干眼治疗中心推荐', '以OPT为主要治疗方式，为患者带来安全、舒适、全面的干眼治疗服务', 'http://admin.m22opt.com/images/opt.png', linkUrl)
    // 加载省市医院
    this.hosarr = await this.getCityDataJson()
    this.hosVal = this.hosarr[0]['children'][0]['text']
    this.hosid = this.hosarr[0]['children'][0]['value']
    // 定位获取医院覆盖默认值
    const initData = await this.getHostpitalListByLatLng()
    if (initData.cityID) {
      this.hosVal = initData.cityName
      this.hosid = initData.proID + '-' + initData.cityID
    }
    this.getHostPitalList()
  },
  mounted() {},
  methods: {
    // 选择城市完成
    onFinishHospitalid({selectedOptions}) {
      this.showHos = false
      // this.hosVal = selectedOptions.map((option) => option.text).join('/')
      this.hosVal = selectedOptions[1]['text']
      this.getHostPitalList()
    },
    // 获取经纬度
    async getHostpitalListByLatLng() {
      const proCity = {
        cityID: '',
        cityName: '',
        proID: '',
        proName: '',
        hosId: '',
        hosName: ''
      }
      return new Promise((resolve, reject) => {
        let data = {
          key: 'RJ4BZ-R353G-AWBQC-IRQEK-MUYSS-PRBZU' //申请的密钥
        }
        let url = 'https://apis.map.qq.com/ws/location/v1/ip' //这个就是地理位置信息的接口
        data.output = 'jsonp'
        this.$jsonp(url, data)
          .then((res) => {
            if (res.status == 0) {
              const latlnglat = res.result.location.lat
              const latlnglng = res.result.location.lng

              GetHostpitalListByLatLng({latlnglat, latlnglng}).then((res) => {
                if (res.length > 0) {
                  proCity.cityID = res[0].CityID
                  proCity.cityName = res[0].CityName
                  proCity.proID = res[0].ProID
                  proCity.proName = res[0].ProName
                  proCity.hosId = res[0].ID
                  proCity.hosName = res[0].Name
                  resolve(proCity)
                } else {
                  resolve(proCity)
                }
              })
            } else {
              // 定位失败
              resolve(proCity)
            }
          })
          .catch((error) => {
            resolve(proCity)
          })
      })
    },
    // 获取省市数据
    async getCityDataJson() {
      const data = await GetCityDataJson()
      return eval('(' + data + ')')
    },
    // 获取省市-医院，三级联动
    // async getHosPitalDataJson() {
    //   const data = await GetHosPitalDataJson()
    //   return eval('(' + data + ')')
    // },
    // 获取医院列表
    getHostPitalList() {
      let data = {
        cityid: this.hosid.split('-')[1]
      }
      GetHostPitalList(data).then((res) => {
        this.hostPitalList = res
      })
    },
    goHos(hosid) {
      this.$router.push({
        path: '/hospital',
        query: {id: hosid}
      })
    },
    returnpage() {
      window.history.back(-1)
    },
    mydiary() {
      this.$router.push({
        path: '/mydiary',
        query: {}
      })
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
