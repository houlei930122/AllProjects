<template>
  <div class="wrap">
    <div class="container">
      <div class="sum-tit"></div>
      <div class="content">
        <div class="tit-wrap">
          <div class="hospital-tit" :style="{'font-size': fontSize + 'px'}">{{ hospitalMsg.Name }}</div>
        </div>
        <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
          <van-swipe-item v-for="item in bannerArr" :key="item.ID">
            <img :src="resetUrl(item.PathUrl)" alt="" srcset="" />
          </van-swipe-item>
        </van-swipe>
        <div class="content-item conetnt1">
          <div class="item-tit"><span>医院介绍</span></div>
          <div class="item-con">
            <div class="specialist-wrap">
              <!-- <div class="specialist-h" style="height:2rem"><img :src="resetUrl(hospitalMsg.Logo)" alt="" srcset="" /></div> -->
              <div class="specialist-msg" style="padding:0">
                <!-- <div class="name" style="font-size:14px">{{ hospitalMsg.Name }}</div>
                <div class="title" style="font-size:13px">地点：{{ hospitalMsg.CityName }}</div> -->
                <div class="msg ">
                  {{ hospitalMsg.Remark }}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-item conetnt1">
          <div class="item-tit"><span>专家介绍</span></div>
          <div class="item-con">
            <div class="specialist-wrap">
              <div class="specialist-h"><img :src="resetUrl(hospitalMsg.DocImage)" alt="" srcset="" /></div>
              <div class="specialist-msg">
                <div class="name">{{ hospitalMsg.DoctorName }}</div>
                <div class="title">{{ hospitalMsg.DoctorTitle }}</div>
                <div class="msg ">
                  {{ hospitalMsg.DoctorDesc }}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-item conetnt2">
          <div class="item-tit"><span>干眼日记</span></div>
          <div class="item-con">
            <div class="diary-list" v-if="diaryList.length > 0">
              <div class="diary-item" v-for="item in diaryList" :key="item.ID" @click="godiary(item.ID)">
                <div class="item-h">
                  <img v-if="item.ImgPath" :src="resetUrl(item.ImgPath)" alt="" />
                  <img v-else src="http://admin.m22opt.com/images/suoluetu.png" alt="" />
                </div>
                <div class="diary-msg">
                  <div class="diary-tit ">{{ item.Title }}</div>
                  <div class="diary-con van-multi-ellipsis--l3">{{ item.Remark }}</div>
                </div>
              </div>
            </div>
            <!-- 暂无数据 -->
            <div class="nodata" v-else>
              <div class="nodata-con">
                <img src="@/assets/images/nodata.png" alt="" />
                <div class="nodata-msg">暂无日志<br />速来分享治疗体验，为医生打call</div>
                <router-link :to="{path: '/edit'}" class="goedit">我要写</router-link>
              </div>
            </div>
          </div>
        </div>
        <div class="content-item conetnt3">
          <div class="item-tit"><span>联系方式</span></div>
          <div class="item-con">
            <div class="tel-wrap">
              <div class="tel-tit">咨询电话：</div>
              <div class="tel-content">
                <div class="tel-num">{{ hospitalMsg.TelePhone }}</div>
                <div class="tel-btn" @click="tel">一键咨询</div>
              </div>
            </div>
            <div class="tel-wrap">
              <div class="tel-tit"></div>
              <div class="tel-content">
                <div class="tel-num">官方微信：</div>
                <div class="tel-btn" @click="addWx(hospitalMsg.WeChatUrl)">一键获取</div>
              </div>
            </div>
            <div class="add-wrap">
              <div class="add-tit">地址：</div>
              <div class="add-content">
                <div class="add-msg">{{ hospitalMsg.Address }}</div>
                <div class="add-btn" @click="add">一键导航</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <van-dialog v-model="show" title="长按识别">
      <img :src="codeImg" />
    </van-dialog>
    <router-link class="lookmore" to="/hospitalList">
      <span>查看<br />更多</span>
    </router-link>
  </div>
</template>

<script>
import {GetHospitalSingle, GetHospitalPicList, GetNewsListByHos, resetUrl} from '../../api/api'
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      id: '',
      fontSize: '15',
      fontText: '',
      show: false,
      codeImg: '/images/code.jpg',
      hospitalMsg: {},
      bannerArr: [],
      diaryList: []
    }
  },
  computed: {},
  watch: {
    fontText(val) {
      const len = val.length
      if (len < 10) {
        this.fontSize = 24
      } else if (len < 14) {
        this.fontSize = 20
      } else {
        this.fontSize = 16
      }
    }
  },
  created() {
    const {id} = this.$route.query
    console.log(id)
    this.id = id
    // 获取医院信息
    GetHospitalSingle({id}).then((res) => {
      console.log(res)
      this.hospitalMsg = res
      this.fontText = res.Name
      const linkUrl = window.location.href
      shareFun(res.Name + 'OPT干眼治疗中心', res.Address, 'http://admin.m22opt.com/images/opt.png', linkUrl)
    })
    // 获取医院benner图
    GetHospitalPicList({id}).then((res) => {
      console.log(res)
      this.bannerArr = res
    })
    // 获取日记列表
    GetNewsListByHos({hosid: id, all: false}).then((res) => {
      console.log(res)
      this.diaryList = res
    })
  },
  mounted() {},
  methods: {
    godiary(id) {
      console.log(id)
      this.$router.push({
        path: '/diary',
        query: {id: id}
      })
    },
    tel() {
      window.location.href = 'tel:' + this.hospitalMsg.TelePhone
    },
    addWx() {
      if (this.hospitalMsg.WeChatUrl) {
        this.codeImg = this.resetUrl(this.hospitalMsg.WeChatUrl)
      }
      this.show = true
    },
    add() {
      // const addres = 'http://api.map.baidu.com/marker?location=31.2328409300,121.4586813102&title=上海市静安区南京西路1376号&content=上海波特曼丽思卡尔顿酒店&output=html'
      // const addres = `http://api.map.baidu.com/marker?location=${this.hospitalMsg.Latitude},${this.hospitalMsg.Longitude}&title=${this.hospitalMsg.Address}&content=${this.hospitalMsg.Name}&output=html`

      const addres = `https://apis.map.qq.com/uri/v1/marker?marker=coord:${this.hospitalMsg.Latitude},${this.hospitalMsg.Longitude};title:${this.hospitalMsg.Address};addr:${this.hospitalMsg.Name}&referer=myapp`

      window.open(addres)
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
