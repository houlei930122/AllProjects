<template>
  <div class="wrap">
    <div class="container">
      <div class="content">
        <div class="sum-tit"></div>
        <img class="tui-tit" src="@/assets/images/exam/tui-tit.png" alt="" />
        <div class="form-wrap">
          <div class="form-tit"><div class="msg">请选择您想预约的医院</div></div>
          <div class="form-content">
            <div class="input-item">
              <input class="input" type="text" v-model="name" placeholder="请输入您的姓名" />
            </div>
            <div class="input-item">
              <input class="input" type="number" v-model="tel" placeholder="请输入您的电话" />
            </div>
            <div class="input-item item-arrow">
              <van-field class="vanfield" v-model="hosVal" readonly @click="showHos = true" />
            </div>
            <!-- <div class="input-item item-arrow"></div> -->
          </div>
        </div>
        <div class="submit-wrap " @click="submit">
          <div class="submit-no"></div>
        </div>
        <div class="note">*问卷为OSDI国际标准干眼自测问卷</div>
      </div>
    </div>
    <van-popup v-model="showHos" round position="bottom">
      <van-cascader v-model="hosid" title="请选择医院" :options="hosarr" @close="showHos = false" @finish="onFinishHospitalid" />
    </van-popup>
  </div>
</template>

<script>
import {GetCityList, GetHostPitalList, SetComments, GetHostpitalListByLatLng, GetCityDataJson, GetHosPitalDataJson} from '../../api/api'
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      name: '',
      tel: '',
      score: '',

      showHos: false,
      hosVal: '', //城市名字
      hosid: '', // 省市id
      hosarr: []
    }
  },
  computed: {},
  watch: {},
  async created() {
    const {score} = this.$route.query
    if (score) {
      this.score = score
    } else {
      this.$router.push({path: '/exam'})
    }
    const linkUrl = window.location.href
    shareFun('寻找OPT', '', 'http://admin.m22opt.com/images/opt.png', linkUrl)

    // 省市医院操作 =======
    // this.shenshiArr = await this.getCityDataJson()
    // console.log(this.shenshiArr)
    // this.cityid = this.shenshiArr[0]['children'][0]['value'] // 设置默认城市选择

    // console.log(this.cityid)
    // 加载省市医院
    this.hosarr = await this.getHosPitalDataJson()
    this.hosVal = this.hosarr[0]['children'][0]['children'][0]['text']
    this.hosid = this.hosarr[0]['children'][0]['children'][0]['value']
    // 定位获取医院覆盖默认值
    const initData = await this.getHostpitalListByLatLng()
    if (initData.cityID) {
      this.hosVal = initData.hosName
      this.hosid = initData.proID + '-' + initData.cityID + '-' + initData.hosId
    }
  },
  mounted() {},
  methods: {
    // 选择城市完成
    onFinishHospitalid({selectedOptions}) {
      this.showHos = false
      // this.hosVal = selectedOptions.map((option) => option.text).join('/')
      this.hosVal = selectedOptions[2]['text']
    },
    // 获取经纬度
    async getHostpitalListByLatLng() {
      const proCity = {
        cityID: '',
        cityName: '',
        proID: '',
        proName: '',
        hosId: '',
        hosName: ''
      }
      return new Promise((resolve, reject) => {
        let data = {
          key: 'RJ4BZ-R353G-AWBQC-IRQEK-MUYSS-PRBZU' //申请的密钥
        }
        let url = 'https://apis.map.qq.com/ws/location/v1/ip' //这个就是地理位置信息的接口
        data.output = 'jsonp'
        this.$jsonp(url, data)
          .then((res) => {
            if (res.status == 0) {
              const latlnglat = res.result.location.lat
              const latlnglng = res.result.location.lng
              GetHostpitalListByLatLng({latlnglat, latlnglng}).then((res) => {
                if (res.length > 0) {
                  proCity.cityID = res[0].CityID
                  proCity.cityName = res[0].CityName
                  proCity.proID = res[0].ProID
                  proCity.proName = res[0].ProName
                  proCity.hosId = res[0].ID
                  proCity.hosName = res[0].Name
                  resolve(proCity)
                } else {
                  resolve(proCity)
                }
              })
            } else {
              // 定位失败
              resolve(proCity)
            }
          })
          .catch((error) => {
            resolve(proCity)
          })
      })
    },
    // 获取省市数据
    async getCityDataJson() {
      const data = await GetCityDataJson()
      return eval('(' + data + ')')
    },
    // 获取省市-医院，三级联动
    async getHosPitalDataJson() {
      const data = await GetHosPitalDataJson()
      return eval('(' + data + ')')
    },
    submit() {
      if (!this.name || !this.tel) {
        this.$toast('请输入姓名或手机号')
        return
      }
      var phoneReg = /^1[3-9][0-9]{9}$/
      if (!phoneReg.test(this.tel)) {
        this.$toast('请输入正确手机号')
        return
      }
      const idArr = this.hosid.split('-')
      const data = {
        name: this.name,
        phone: this.tel,
        city: idArr[1],
        hosital: idArr[2],
        score: parseInt(this.score)
      }
      SetComments(data)
        .then((res) => {
          this.$router.push({
            path: '/hospital',
            query: {id: idArr[2]}
          })
        })
        .catch((err) => {
          this.$toast('提交失败')
        })
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
