<template>
  <div class="container">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide swiper-no-swiping">
          <!-- <Home class="ani" swiper-animate-effect="bounceInLeft" swiper-animate-duration="0.5s" swiper-animate-delay="0s"></Home> -->
          <div class="loading-wrap">
            <div class="loading-con">
              <img src="images/exam/loading.gif" alt="" srcset="" /><br />
              <div class="loading-num">
                Loading&ensp;<span>{{ nump }}%</span>&ensp;...
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide swiper-no-swiping">
          <div class="home-wrap">
            <div class="home-con">
              <div class="home-logo" />
              <div class="home-tit"></div>
              <div class="gun"></div>
              <div class="warn-bg">
                <div class="warn-word">
                  <span class="ani" swiper-animate-effect="wordWidth" swiper-animate-duration="1s" swiper-animate-delay="0.5s">中国每5人中就有1人患有干眼</span>
                  <span class="ani" swiper-animate-effect="wordWidth" swiper-animate-duration="1s" swiper-animate-delay="1.5s">干眼症可能早已缠上你，速测！</span>
                </div>
              </div>
              <div class="home-center">
                <div class="flash ani" swiper-animate-effect="flash" swiper-animate-duration="1s" swiper-animate-delay="0.5s"></div>
                <img class="eye ani" swiper-animate-effect="zoomIn" swiper-animate-duration="1s" swiper-animate-delay="0.5s" src="images/exam/eye.png" />
                <img class="msg0 ani" swiper-animate-effect="zoomIn" swiper-animate-duration="1s" swiper-animate-delay="0.5s" src="images/exam/msg0.png" />
                <img class="msg1 ani" swiper-animate-effect="msgani1" swiper-animate-duration="1s" swiper-animate-delay="1.5s" src="images/exam/msg1.png" />
                <img class="msg2 ani" swiper-animate-effect="msgani2" swiper-animate-duration="1s" swiper-animate-delay="2s" src="images/exam/msg2.png" />
                <img class="msg3 ani" swiper-animate-effect="msgani3" swiper-animate-duration="1s" swiper-animate-delay="2.5s" src="images/exam/msg3.png" />
                <img class="msg4 ani" swiper-animate-effect="msgani4" swiper-animate-duration="1s" swiper-animate-delay="3s" src="images/exam/msg4.png" />
                <img class="msg5 ani" swiper-animate-effect="msgani5" swiper-animate-duration="1s" swiper-animate-delay="3.5s" src="images/exam/msg5.png" />
              </div>
              <div class="start-wrap" @click="start">
                <div class="start-btn1" v-show="startSwitch"></div>
                <div class="start-btn2" v-show="!startSwitch"></div>
              </div>
              <div class="note">*问卷为OSDI国际标准干眼自测问卷</div>
            </div>
          </div>
        </div>
        <div class="swiper-slide exam-wrap swiper-no-swiping" v-for="(item, index) in questionList" :key="index">
          <div class="exam-item">
            <div class="item-con">
              <img class="q-logo" src="@/assets/images/exam/q-logo.png" alt="" srcset="" />
              <div class="q-msg ani" swiper-animate-effect="fadeIn" swiper-animate-duration="1s" swiper-animate-delay="0s">
                <img :src="['images/exam/' + item.qimg]" alt="" srcset="" />
              </div>
              <div class="option-list">
                <div
                  class="option-item option-item1 ani"
                  swiper-animate-effect="fadeInRight"
                  swiper-animate-duration="0.5s"
                  swiper-animate-delay="0s"
                  :class="[item.answer == 0 ? 'act' : '']"
                  @click="slideNext(index, 0)"
                ></div>
                <div
                  class="option-item option-item2 ani"
                  swiper-animate-effect="fadeInRight"
                  swiper-animate-duration="0.5s"
                  swiper-animate-delay="0.2s"
                  :class="[item.answer == 1 ? 'act' : '']"
                  @click="slideNext(index, 1)"
                ></div>
                <div
                  class="option-item option-item3 ani"
                  swiper-animate-effect="fadeInRight"
                  swiper-animate-duration="0.5s"
                  swiper-animate-delay="0.4s"
                  :class="[item.answer == 2 ? 'act' : '']"
                  @click="slideNext(index, 2)"
                ></div>
                <div
                  class="option-item option-item4 ani"
                  swiper-animate-effect="fadeInRight"
                  swiper-animate-duration="0.5s"
                  swiper-animate-delay="0.6s"
                  :class="[item.answer == 3 ? 'act' : '']"
                  @click="slideNext(index, 3)"
                ></div>
                <div
                  class="option-item option-item5 ani"
                  swiper-animate-effect="fadeInRight"
                  swiper-animate-duration="0.5s"
                  swiper-animate-delay="0.8s"
                  :class="[item.answer == 4 ? 'act' : '']"
                  @click="slideNext(index, 4)"
                ></div>
              </div>
              <div class="q-note">*问卷为OSDI国际标准干眼自测问卷</div>
            </div>
          </div>
        </div>
        <div class="swiper-slide swiper-no-swiping">
          <div class="loading-wrap">
            <img class="q-logo" src="@/assets/images/exam/q-logo.png" alt="" srcset="" />
            <div class="loading-con">
              <img src="images/exam/loading.gif" alt="" srcset="" /><br />
              <div class="loading-num">
                结果生成中&ensp;<span>{{ numsuc }}%</span>&ensp;...
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide swiper-no-swiping respage">
          <div class="res-wrap">
            <div class="res-con">
              <div class="res-logo" />
              <div class="res-msg " :class="showResArr[showIndex]['bgcalss']">
                <div class="grade">{{ result }}</div>
                <div class="res-word">{{ showResArr[showIndex]['word'][0] }}<br />{{ showResArr[showIndex]['word'][1] }}</div>
              </div>
              <div class="btn-wrap">
                <div class="save-btn"><img :src="shareImg" alt="" srcset="" /></div>
                <router-link class="search-btn" :to="{path: '/subscribe', query: {score: result}}"></router-link>
              </div>
              <div class="note">*问卷为OSDI国际标准干眼自测问卷</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Swiper from 'swiper'
import 'swiper/css/swiper.min.css'
import * as swiperAni from '../../utils/animate'
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      startSwitch: true,
      questionList: [
        {
          qimg: 'q-1.png',
          answer: null
        },
        {
          qimg: 'q-2.png',
          answer: null
        },
        {
          qimg: 'q-3.png',
          answer: null
        },
        {
          qimg: 'q-4.png',
          answer: null
        },
        {
          qimg: 'q-5.png',
          answer: null
        },
        {
          qimg: 'q-6.png',
          answer: null
        },
        {
          qimg: 'q-7.png',
          answer: null
        },
        {
          qimg: 'q-8.png',
          answer: null
        },
        {
          qimg: 'q-9.png',
          answer: null
        },
        {
          qimg: 'q-10.png',
          answer: null
        },
        {
          qimg: 'q-11.png',
          answer: null
        },
        {
          qimg: 'q-12.png',
          answer: null
        }
      ],
      nump: 0,
      numsuc: 0,
      mySwiper: null,
      timerStart: null,
      timerQ: null,
      result: null, // 最终成绩
      showIndex: 0,
      showResArr: [
        {
          word: ['眼健康达人就是你', '请继续保持良好用眼习惯噢！'],
          bgcalss: 'cardbg1',
          card: 'card1.png'
        },
        {
          word: ['你的干眼程度为轻度干眼', '小心！干眼已经缠上了你'],
          bgcalss: 'cardbg2',
          card: 'card2.png'
        },
        {
          word: ['你的干眼程度为中度干眼', '干眼不可怕，可怕的是你的不重视'],
          bgcalss: 'cardbg3',
          card: 'card3.png'
        },
        {
          word: ['你的干眼程度为重度干眼', '干眼可能已经影响了你的正常生活！'],
          bgcalss: 'cardbg4',
          card: 'card4.png'
        }
      ],
      shareImg: ''
    }
  },
  computed: {},
  watch: {},
  created() {
    this.loadding()
    const linkUrl = window.location.href
    shareFun('测一测你的干眼程度', '眼干、眼涩，干眼症可能已经缠上你，速测', 'http://admin.m22opt.com/images/zice.png', linkUrl)
  },
  mounted() {
    // this.timerStart = setInterval(() => {
    //   this.startSwitch = !this.startSwitch
    // }, 300)
    const that = this
    this.$nextTick(function() {
      //因为初始化swiper需要获取dom节点，所以要将初始化的代码写入 this.$nexTick 里，或者写在mounted钩子函数里

      that.mySwiper = new Swiper('.swiper-container', {
        effect: 'fade',
        observer: true,
        // initialSlide: 14,
        on: {
          init: function() {
            swiperAni.swiperAnimateCache(this) //隐藏动画元素
            swiperAni.swiperAnimate(this) //初始化完成开始动画
          },
          slideChangeTransitionStart: function() {
            swiperAni.swiperAnimate(this) //每个slide开始切换时也运行当前slide动画
            //this.slides.eq(this.activeIndex).find('.ani').removeClass('ani'); 动画只展现一次，去除ani类名
          },
          slideChange: function() {
            const activeIndex = this.activeIndex
          }
        }
      })
    })
  },
  //   最终OSDI评分=25×得分总和/所回答问题总数。
  // 0-12为正常
  // 评分≤20分为轻度症状；
  // 评分21~45分为中度症状；
  // 评分≥46分为重度症状；
  methods: {
    slideNext(qindex, ansindex) {
      clearTimeout(this.timerQ)
      this.questionList[qindex]['answer'] = ansindex
      if (qindex == 11) {
        this.timerQ = setTimeout(() => {
          this.mySwiper.slideNext()
          this.tores()
        }, 400)
        this.result = Math.floor(
          this.questionList.reduce((acc, cur) => {
            return acc + cur.answer
          }, 0)
        )
        console.log(this.result)
        if (this.result <= 12) {
          this.showIndex = 0
        } else if (this.result <= 20) {
          this.showIndex = 1
        } else if (this.result <= 45) {
          this.showIndex = 2
        } else {
          this.showIndex = 3
        }
        this.createimg()
      } else {
        this.timerQ = setTimeout(() => {
          this.mySwiper.slideNext()
        }, 400)
      }
    },
    start() {
      this.startSwitch = false
      setTimeout(() => {
        this.mySwiper.slideTo(2)
      }, 200)
    },
    tores() {
      const sucTimer = setInterval(() => {
        this.numsuc++
        if (this.numsuc >= 100) {
          clearInterval(sucTimer)
          this.mySwiper.slideNext()
        }
      }, 30)
    },
    loadding() {
      const that = this
      var pro = ['q-1.png', 'loading.gif', 'eye.png', 'msg0.png', 'msg1.png', 'msg2.png', 'msg3.png', 'msg4.png', 'msg5.png'], //存放图片路径的数组
        i = 0, //从第几张开始
        timer = null, //计时器
        len = pro.length,
        load = function(src) {
          if (i < len) {
            var img_obj = new Image()
            img_obj.src = 'images/exam/' + src
            timer = setInterval(function() {
              if (img_obj.complete) {
                clearInterval(timer)
                load(pro[++i])
                that.nump = Math.ceil((i * 100) / len)
              }
            }, 20)
          } else {
            that.mySwiper.slideNext()
          }
        }
      load(pro[i])
    },
    createimg() {
      const that = this
      var data = ['images/exam/' + this.showResArr[this.showIndex]['card']]
      var len = data.length
      var canvas = document.createElement('canvas')
      var ctx = canvas.getContext('2d')
      canvas.width = '750'
      canvas.height = '1334'
      function drawing(n) {
        if (n < len) {
          var img = new Image()
          img.crossOrigin = 'Anonymous' //解决跨域
          img.src = data[n]
          img.onload = function() {
            if (n == 0) {
              ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
            }
            drawing(n + 1) //递归
          }
        } else {
          ctx.font = '60px Impact'
          ctx.textAlign = 'right'
          ctx.textBaseline = 'top'
          ctx.fillStyle = '#5268FF'
          ctx.fillText(that.result, 502, 368)
          ctx.font = '28px PingFangSC-Semibold, PingFang SC bold'
          ctx.fillStyle = '#fff'
          ctx.textAlign = 'left'
          ctx.fillText(that.showResArr[that.showIndex]['word'][0], 123, 504)
          ctx.fillText(that.showResArr[that.showIndex]['word'][1], 123, 539)
          //保存生成作品图片
          that.shareImg = canvas.toDataURL('image/jpeg', 1)
        }
      }
      drawing(0)
    }
  }
}
</script>

<style lang="less" scoped>
@import url('../../styles/animate.min.css');
@import url('./style.less');
</style>
