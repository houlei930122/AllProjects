<template>
  <div class="app-wrapper">
    <header class="header-container">
      <van-nav-bar :title="title"
                   left-arrow
                   safe-area-inset-top
                   @click-left="onClickLeft">
        <template #right>
          <van-icon name="browsing-history"
                    class="change-color"
                    @click="setColor"
                    size="18"></van-icon>
          <van-icon name="setting"
                    size="18"
                    class="setting"
                    @click="setFonts"></van-icon>
        </template>
      </van-nav-bar>
    </header>
    <main class="main-container">
      <slot />
    </main>
  </div>
</template>

<script>
export default {
  name: 'ExamLayout',
  components: {

  },
  data () {
    return {
      loading: false,
      safearea: true
    }
  },
  computed: {
    title () {
      return this.$route.meta.title
    }
  },
  watch: {

  },
  methods: {
    onClickLeft () {
      this.backPage()
    },
    setColor () {
      console.log('设置颜色')
    },
    setFonts () {
      console.log('设置字体')
    }
  }
}
</script>

<style  lang="less">
.app-wrapper {
  position: relative;
  width: 100%;
  height: 100%;
  padding-top: 48px;
  .header-container {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    z-index: 8989;
  }
}
.van-nav-bar__content {
  height: 48px;
}
.main-container {
  position: relative;
  width: 100%;
  height: 100%;
}
</style>
