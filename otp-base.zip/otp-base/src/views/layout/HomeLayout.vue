<template>
  <div class="app-wrapper">
    <header class="header-container">
      <van-sticky :offset-top="0">
        <slot name="header">
          <nav-bar />
        </slot>
      </van-sticky>
    </header>
    <main ref="main" class="main-container">
      <loading v-if="loading" />
      <slot />
    </main>
    <footer class="footer-container">
      <home-tabbar :list="homeTabbars" />
    </footer>
  </div>
</template>

<script>
import HomeTabbar from './components/HomeTabbar'
import NavBar from './components/NavBar'
import { mapGetters } from 'vuex'
import Loading from '@/components/Loading'
import { throttle } from '@/utils'
import { Sticky } from 'vant'

export default {
  name: 'HomeLayout',
  components: { HomeTabbar, NavBar, Loading, [Sticky.name]: Sticky },
  props: {
    activeClass: {
      type: String,
      default() {
        return ''
      }
    }
  },
  data() {
    return {
      loading: false
    }
  },
  computed: {
    ...mapGetters(['pageInit', 'loadingNum', 'homeTabbars'])
  },
  watch: {
    loadingNum(count) {
      // count > 0 表示有ajax请求正在执行中，pageInit表示刚进入新页面，loading表示页面loading的状态
      if (count > 0 && this.pageInit && this.loading === false) {
        this.loading = true
      }
      if (count === 0) {
        this.loading = false
        this.$store.commit('app/SET_PAGEINIT', false)
      }
    }
  },
  created() {
    this.getHomeTabbar()
  },
  mounted() {
    window.addEventListener('scroll', this.handleScroll)
  },
  methods: {
    getHomeTabbar() {
      this.$store
        .dispatch('pages/getHomeTabbars')
        .then((res) => {})
        .catch((e) => {
          console.log(e)
        })
    },
    handleScroll: throttle(function() {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
      this.$emit('update:activeClass', scrollTop > 50 ? 'active' : '')
    })
    // handleScroll: throttle(function() {
    //   // 内容区域滚动时监听其滚动
    //   var scrollTop = this.$refs.main.scrollTop
    //   this.$emit('update:activeClass', scrollTop > 50 ? 'active' : '')
    // })
  }
}
</script>

<style scoped lang="less">
/deep/ .main-container {
  padding-bottom: @tabbar-height;
}

/deep/ .van-loading {
  height: calc(100vh - @tabbar-height);
}
</style>
