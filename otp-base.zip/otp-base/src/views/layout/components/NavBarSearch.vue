<template>
  <van-search v-model="value" disabled :placeholder="placeholder">
    <template #left>
      <van-icon name="arrow-left" @click="backPage" />
    </template>
  </van-search>
</template>

<script>
import { Search } from 'vant'
export default {
  name: 'NavBarSearch',
  components: {
    [Search.name]: Search
  },
  props: {
    placeholder: {
      type: String,
      default() {
        return '请输入搜索关键词'
      }
    },
    value: {
      type: String,
      default() {
        return ''
      }
    }
  }
}
</script>

<style scoped lang="less">
.van-icon-arrow-left {
  font-size: @nav-bar-arrow-size;
  padding-right: 10px;
}
</style>
