<template>
  <van-nav-bar :title="title" left-arrow safe-area-inset-top @click-left="onClickLeft" />
</template>

<script>
import { NavBar } from 'vant'
export default {
  name: 'NavBar',
  components: {
    [NavBar.name]: NavBar
  },
  computed: {
    title() {
      return this.$route.meta.title
    }
  },
  methods: {
    onClickLeft() {
      this.backPage()
    }
  }
}
</script>

<style scoped lang="less"></style>
