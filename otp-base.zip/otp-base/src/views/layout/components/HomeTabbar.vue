<template>
  <van-tabbar class="active_tab" route>
    <van-tabbar-item v-for="(item, index) in list" :key="index" :to="{ path: item.path }">
      <span>{{ item.title }}</span>
      <template #icon="props">
        <van-image lazy-load width="23" height="22" :src="props.active ? item.active : item.inactive" />
      </template>
    </van-tabbar-item>
  </van-tabbar>
</template>

<script>
import { Tabbar, TabbarItem } from 'vant'
export default {
  name: 'Tabbar',
  components: {
    [Tabbar.name]: Tabbar,
    [TabbarItem.name]: TabbarItem
  },
  props: {
    list: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      publicPath: process.env.BASE_URL // 获取静态资源路径
    }
  },
  methods: {}
}
</script>

<style lang="less" scoped>
/deep/ .van-image__error-icon {
  font-size: 28px;
}
/deep/ .van-tabbar-item__icon {
  margin-bottom: 0;
}
</style>
