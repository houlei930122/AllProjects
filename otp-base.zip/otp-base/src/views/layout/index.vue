<template>
  <div class="app-wrapper">
    <header class="header-container">
      <van-sticky :offset-top="0">
        <slot name="header">
          <nav-bar />
        </slot>
      </van-sticky>
    </header>
    <main class="main-container">
      <loading v-if="loading" />
      <slot />
    </main>
  </div>
</template>

<script>
import NavBar from './components/NavBar'
import { Sticky } from 'vant'
import Loading from '@/components/Loading'
import { mapGetters } from 'vuex'

export default {
  name: 'Layout',
  components: {
    NavBar,
    Loading,
    [Sticky.name]: Sticky
  },
  data() {
    return {
      loading: false
    }
  },
  computed: {
    ...mapGetters(['pageInit', 'loadingNum'])
  },
  watch: {
    loadingNum(count) {
      // count > 0 表示有ajax请求正在执行中，pageInit表示刚进入新页面，loading表示页面loading的状态
      if (count > 0 && this.pageInit && this.loading === false) {
        this.loading = true
      }
      if (count === 0) {
        this.loading = false
        this.$store.commit('app/SET_PAGEINIT', false)
      }
    }
  }
}
</script>

<style scoped lang="less">
/deep/ .van-loading {
  height: calc(100vh - @nav-bar-height);
  top: @nav-bar-height;
}
</style>
