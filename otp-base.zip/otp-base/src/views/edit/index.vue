<template>
  <div class="wrap">
    <div class="container">
      <div class="sum-tit"></div>

      <div class="diary-wrap">
        <div class="diary-content">
          <div class="diary-cen">
            <div class="select-wrap">
              <div class="select-area">
                <van-field class="vanfield1" v-model="hosVal" readonly @click="showHos = true" />
              </div>
              <!-- <div class="select-hospital">
                <van-dropdown-menu>
                  <van-dropdown-item v-model="hospital" :options="hospitalarr" />
                </van-dropdown-menu>
              </div> -->
            </div>
            <div class="title-wrap">
              <div class="title-msg">标题</div>
              <div class="title-con">
                <input type="text" v-model="title" />
              </div>
            </div>
            <div class="upload-wrap">
              <div class="upload-tit">图片</div>
              <div class="upload-con">
                <van-uploader v-model="fileList" :max-size="10000 * 1024" @oversize="onOversize" max-count="4" :after-read="afterRead" :before-delete="deleteImg" />
              </div>
            </div>
            <div class="diary-con">
              <div class="diary-center">
                <textarea name="" id="" v-model="diary" placeholder="请输入..."></textarea>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="write-wrap" @click="uploadDiary"></div>
    </div>
    <van-popup v-model="showHos" round position="bottom">
      <van-cascader v-model="hosid" title="请选择医院" :options="hosarr" @close="showHos = false" @finish="onFinishHospitalid" />
    </van-popup>
  </div>
</template>

<script>
import {GetNewsDetail, GetNewsPicList, GetCityList, GetHostPitalList, GetHostpitalListByLatLng, UploadFile, InsertNews, DeleteImages, GetCityDataJson, GetHosPitalDataJson} from '../../api/api'
import {getToken} from '@/utils/auth'
export default {
  components: {},
  props: {},
  data() {
    return {
      id: 0, //日记id
      title: '',
      diary: '',
      firstCity: true,
      nGuId: '',
      fileList: [],
      showHos: false,
      hosVal: '', //城市名字
      hosid: '', // 省市id
      hosarr: []
    }
  },
  computed: {},

  async created() {
    const {id} = this.$route.query
    this.id = parseInt(id) || 0
    // 加载省市医院
    this.hosarr = await this.getHosPitalDataJson()
    this.hosVal = this.hosarr[0]['children'][0]['children'][0]['text']
    this.hosid = this.hosarr[0]['children'][0]['children'][0]['value']
    // 判断id是否存在，存在为修改，不存在未新建
    if (this.id) {
      GetNewsDetail({id}).then((res) => {
        this.title = res.Title
        this.diary = res.Remark
        this.city = res.CityID
        this.hospital = res.HosId
        this.nGuId = res.nGuId
        // this.initCityH()
        // !需要等接口修改后处理初始化
        this.hosVal = res.HospitalName
        this.hosid = res.ProID + '-' + res.CityID + '-' + res.HosId
      })
      GetNewsPicList({id}).then((res) => {
        for (let i = 0; i < res.length; i++) {
          const obj = {
            url: this.resetUrl(res[i]['PathUrl']),
            id: res[i]['ID']
          }
          this.fileList.push(obj)
        }
      })
    } else {
      this.nGuId = this.newGuids()
      // 定位获取医院覆盖默认值
      const initData = await this.getHostpitalListByLatLng()
      console.log(initData)
      if (initData.cityID) {
        this.hosVal = initData.hosName
        this.hosid = initData.proID + '-' + initData.cityID + '-' + initData.hosId
      }
    }
  },
  mounted() {},
  methods: {
    // 选择城市完成
    onFinishHospitalid({selectedOptions}) {
      this.showHos = false
      // this.hosVal = selectedOptions.map((option) => option.text).join('/')
      this.hosVal = selectedOptions[2]['text']
      // this.getNewsListByHos(selectedOptions[2]['id'])
    },
    // 获取经纬度
    async getHostpitalListByLatLng() {
      const proCity = {
        cityID: '',
        cityName: '',
        proID: '',
        proName: '',
        hosId: '',
        hosName: ''
      }
      return new Promise((resolve, reject) => {
        let data = {
          key: 'RJ4BZ-R353G-AWBQC-IRQEK-MUYSS-PRBZU' //申请的密钥
        }
        let url = 'https://apis.map.qq.com/ws/location/v1/ip' //这个就是地理位置信息的接口
        data.output = 'jsonp'
        this.$jsonp(url, data)
          .then((res) => {
            if (res.status == 0) {
              const latlnglat = res.result.location.lat
              const latlnglng = res.result.location.lng
              GetHostpitalListByLatLng({latlnglat, latlnglng}).then((res) => {
                if (res.length > 0) {
                  proCity.cityID = res[0].CityID
                  proCity.cityName = res[0].CityName
                  proCity.proID = res[0].ProID
                  proCity.proName = res[0].ProName
                  proCity.hosId = res[0].ID
                  proCity.hosName = res[0].Name
                  resolve(proCity)
                } else {
                  resolve(proCity)
                }
              })
            } else {
              // 定位失败
              resolve(proCity)
            }
          })
          .catch((error) => {
            resolve(proCity)
          })
      })
    },
    // 获取省市数据
    async getCityDataJson() {
      const data = await GetCityDataJson()
      return eval('(' + data + ')')
    },
    // 获取省市-医院，三级联动
    async getHosPitalDataJson() {
      const data = await GetHosPitalDataJson()
      return eval('(' + data + ')')
    },

    afterRead(file) {
      console.log(file)
      var formData = new FormData()
      formData.append('v', 'upload')
      formData.append('base64_string', file.content)
      formData.append('titleid', this.nGuId)
      formData.append('type', 2)

      console.log(this.fileList)
      this.fileList.pop()
      try {
        UploadFile(formData)
          .then((res) => {
            console.log(res)
            file.id = res.imgId
            this.fileList.push(file)
          })
          .catch((err) => {
            // this.fileList.pop()
            this.$toast(err)
          })
      } catch (error) {
        // this.fileList.pop()
        this.$toast(error)
      }
    },
    deleteImg(file) {
      // 删除图片
      console.log(file)
      return new Promise((resolve, reject) => {
        this.$dialog
          .confirm({
            title: '',
            message: '确认删除图片吗'
          })
          .then(() => {
            DeleteImages({id: file.id}).then((res) => {
              console.log(res)
              resolve()
            })
          })
          .catch(() => {
            reject()
          })
      })
    },
    onOversize(file) {
      console.log(file)
      this.$toast('文件大小不能超过 10MB')
    },
    //上传日记
    uploadDiary() {
      const data = {
        id: this.id, // 新增 id 为 0
        title: this.title,
        hosid: this.hosid.split('-')[2],
        content: this.diary,
        memberid: getToken(),
        guids: this.nGuId
      }
      InsertNews(data).then((res) => {
        console.log(res)
        this.$toast(res.msg)
        if (res.status == 0) {
          setTimeout(() => {
            this.$router.push({path: '/mydiary'})
          }, 500)
        }
      })
    },

    newGuids() {
      // 生成guids
      var resa = ''
      for (var i = 1; i <= 32; i++) {
        var n = Math.floor(Math.random() * 16.0).toString(16)
        resa += n
        if (i == 8 || i == 12 || i == 16 || i == 20) resa += '-'
      }
      var guid = resa.replace(/\{|\(|\)|\}|-/g, '').toUpperCase()
      return guid
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
