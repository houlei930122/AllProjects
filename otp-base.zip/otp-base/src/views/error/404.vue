<template>
  <layout>
    404
  </layout>
</template>

<script>
import Layout from '@/views/layout'
export default {
  name: '404',
  components: { Layout },
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
