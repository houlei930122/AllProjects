<template>
  <div class="wrap">
    <div class="container">
      <div class="sum-tit"></div>
      <div class="header-content">
        <img class="diary-tit-img" src="@/assets/images/diary-tit.png" alt="" srcset="" />
        <van-swipe class="my-swipe" v-if="bannerArr.length > 0" :autoplay="3000" indicator-color="white">
          <van-swipe-item class="swiper-tem" v-for="item in bannerArr" :key="item.ID">
            <img :src="resetUrl(item.Spath)" alt="" srcset="" />
          </van-swipe-item>
        </van-swipe>
      </div>
      <!-- 返回 我的按钮 -->
      <div class="btn-wrap">
        <!-- <div class="return-wrap" @click="returnpage">
          <div class="return-msg"><span>返回</span></div>
        </div> -->
        <div class="mydiary-wrap" @click="mydiary">
          <div class="mydiary-msg"><span>我的日记</span></div>
        </div>
      </div>
      <div class="diary-wrap">
        <div class="diary-content">
          <div class="select-wrap">
            <div class="select-area">
              <van-field class="vanfield1" v-model="hosVal" readonly @click="showHos = true" />
            </div>
            <!-- <div class="select-hospital">
              <van-dropdown-menu>
                <van-dropdown-item v-model="hospital" :options="hospitalarr" />
              </van-dropdown-menu>
            </div> -->
          </div>
          <div class="diary-list" v-if="diaryList.length > 0">
            <div class="diary-item" v-for="item in diaryList" :key="item.ID" @click="godiary(item.ID)">
              <div class="item-h">
                <img v-if="item.ImgPath" :src="resetUrl(item.ImgPath)" alt="" />
                <img v-else src="http://admin.m22opt.com/images/suoluetu.png" alt="" />
              </div>
              <div class="diary-msg">
                <div class="diary-tit van-ellipsis">{{ item.Author }}的干眼日记</div>
                <div class="diary-con van-multi-ellipsis--l3">{{ item.Remark }}</div>
              </div>
            </div>
          </div>
          <!-- 暂无数据 -->
          <div class="nodata" v-else>
            <div class="nodata-con">
              <img src="@/assets/images/nodata.png" alt="" />
              <div class="nodata-msg">暂无日志<br />速来分享治疗体验</div>
              <router-link :to="{path: '/edit'}" class="goedit">我要写</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
    <van-popup v-model="showHos" round position="bottom">
      <van-cascader v-model="hosid" title="请选择医院" :options="hosarr" @close="showHos = false" @finish="onFinishHospitalid" />
    </van-popup>
  </div>
</template>

<script>
import {getBannerList, GetHostpitalListByLatLng, GetCityList, GetHostPitalList, GetNewsListByHos, GetCityDataJson, GetHosPitalDataJson} from '../../api/api'
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      bannerArr: [],
      showHos: false,
      hosVal: '', //城市名字
      hosid: '', // 省市id
      hosarr: [],
      diaryList: [] // 医院日记列表
    }
  },

  async created() {
    const linkUrl = window.location.href
    shareFun('OPT干眼治疗中心干眼日记', '分享治疗体验，为医院和专家打call', 'http://admin.m22opt.com/images/riji.png', linkUrl)
    // 获取banner
    getBannerList().then((res) => {
      console.log(res)
      this.bannerArr = res
    })
    // 加载省市医院
    this.hosarr = await this.getHosPitalDataJson()
    this.hosVal = this.hosarr[0]['children'][0]['children'][0]['text']
    this.hosid = this.hosarr[0]['children'][0]['children'][0]['value']
    // 定位获取医院覆盖默认值
    const initData = await this.getHostpitalListByLatLng()
    if (initData.cityID) {
      this.hosVal = initData.hosName
      this.hosid = initData.proID + '-' + initData.cityID + '-' + initData.hosId
    }
    // 加载医院日记列表
    this.getNewsListByHos(this.hosid.split('-')[2])
  },
  mounted() {},
  methods: {
    // 选择城市完成
    onFinishHospitalid({selectedOptions}) {
      this.showHos = false
      // this.hosVal = selectedOptions.map((option) => option.text).join('/')
      this.hosVal = selectedOptions[2]['text']
      this.getNewsListByHos(selectedOptions[2]['id'])
    },
    // 获取经纬度
    async getHostpitalListByLatLng() {
      const proCity = {
        cityID: '',
        cityName: '',
        proID: '',
        proName: '',
        hosId: '',
        hosName: ''
      }
      return new Promise((resolve, reject) => {
        let data = {
          key: 'RJ4BZ-R353G-AWBQC-IRQEK-MUYSS-PRBZU' //申请的密钥
        }
        let url = 'https://apis.map.qq.com/ws/location/v1/ip' //这个就是地理位置信息的接口
        data.output = 'jsonp'
        this.$jsonp(url, data)
          .then((res) => {
            if (res.status == 0) {
              const latlnglat = res.result.location.lat
              const latlnglng = res.result.location.lng
              GetHostpitalListByLatLng({latlnglat, latlnglng}).then((res) => {
                if (res.length > 0) {
                  proCity.cityID = res[0].CityID
                  proCity.cityName = res[0].CityName
                  proCity.proID = res[0].ProID
                  proCity.proName = res[0].ProName
                  proCity.hosId = res[0].ID
                  proCity.hosName = res[0].Name
                  resolve(proCity)
                } else {
                  resolve(proCity)
                }
              })
            } else {
              // 定位失败
              resolve(proCity)
            }
          })
          .catch((error) => {
            resolve(proCity)
          })
      })
    },
    // 获取省市数据
    async getCityDataJson() {
      const data = await GetCityDataJson()
      return eval('(' + data + ')')
    },
    // 获取省市-医院，三级联动
    async getHosPitalDataJson() {
      const data = await GetHosPitalDataJson()
      return eval('(' + data + ')')
    },
    returnpage() {
      window.history.back(-1)
    },
    mydiary() {
      this.$router.push({path: '/mydiary'})
    },
    // 查看日记
    godiary(id) {
      console.log(id)
      this.$router.push({
        path: '/diary',
        query: {id: id}
      })
    },

    // 获取日记列表
    getNewsListByHos(hosid) {
      GetNewsListByHos({hosid: hosid, all: true}).then((res) => {
        console.log(res)
        this.diaryList = res
      })
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
