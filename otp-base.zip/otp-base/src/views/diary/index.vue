<template>
  <div class="wrap">
    <div class="container">
      <div class="sum-tit"></div>
      <div class="header-content">
        <img class="diary-tit-img" src="@/assets/images/diary-tit.png" alt="" srcset="" />
      </div>

      <div class="diary-wrap">
        <div class="diary-content">
          <div class="diary-cen">
            <div class="diary-title">{{ diary.Title }} {{ diary.Author }}</div>

            <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
              <van-swipe-item class="swiper-tem" v-for="item in banner" :key="item.ID">
                <img :src="resetUrl(item.PathUrl)" alt="" srcset="" />
              </van-swipe-item>
            </van-swipe>
            <div class="diary-smg" v-html="content"></div>
          </div>
          <div class="pageview">
            <div class="viewnum">
              阅读量<span>{{ diary.SeeCount }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 操作按钮，根据用户判断展示不同的按钮 -->
      <div class="write-wrap" v-if="!self" @click="writeSelf"></div>
      <div class="self-wrap" v-else>
        <div class="del" @click="deldiary"></div>
        <div class="amend" @click="putdiary"></div>
        <div class="mywrite" @click="writeSelf"></div>
      </div>
    </div>
    <router-link class="lookmore" to="/sumdiary">
      <span>查看<br />更多</span>
    </router-link>
  </div>
</template>

<script>
import {GetNewsDetail, GetNewsPicList, SetSeeCount, DeleteNews} from '../../api/api'
import {getToken, setToken} from '@/utils/auth' //
import {shareFun} from '../../utils/index'
export default {
  components: {},
  props: {},
  data() {
    return {
      self: false,
      id: '',
      content: '',
      diary: {}, // MemerId 判断是否是当前用户
      banner: []
    }
  },
  computed: {},
  watch: {},
  created() {
    const {id} = this.$route.query
    console.log(id)
    this.id = id
    SetSeeCount({id: id}).then((res) => {
      console.log(res)
    })
    GetNewsDetail({id}).then((res) => {
      console.log(res)
      this.diary = res
      this.content = res.Remark.replace(/\n/g, '<br />')
      // 判断使用用户自己打开了自己的日记
      if (getToken() == res.MemerId) {
        this.self = true
      }
      const linkUrl = window.location.href
      shareFun('OPT干眼治疗中心干眼日记', '分享治疗体验，为医院和专家打call', 'http://admin.m22opt.com/images/riji.png', linkUrl)
    })
    GetNewsPicList({id}).then((res) => {
      console.log(res)
      this.banner = res
    })
  },
  mounted() {},
  methods: {
    mydiary() {
      this.$router.push({path: '/mydiary'})
    },
    writeSelf() {
      this.$router.push({path: '/edit'})
    },
    // 删除日记
    deldiary() {
      // 执行删除逻辑，返回上一页
      this.$dialog
        .confirm({
          title: '提示',
          message: '确认删除该日记吗？'
        })
        .then(() => {
          DeleteNews({id: this.id}).then((res) => {
            window.history.back()
          })
        })
        .catch(() => {})
    },
    // 修改日记
    putdiary() {
      this.$router.push({path: '/edit', query: {id: this.id}})
    }
  }
}
</script>

<style lang="less" scoped>
@import url('./index.less');
</style>
