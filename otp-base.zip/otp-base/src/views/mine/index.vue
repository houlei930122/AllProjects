<template>
  <home-layout />
</template>

<script>
import HomeLayout from '@/views/layout/HomeLayout'
export default {
  name: 'Mine',
  components: {
    HomeLayout
  },
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
