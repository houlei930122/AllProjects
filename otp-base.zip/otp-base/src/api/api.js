import request from '@/utils/request'

const baseApi = process.env.VUE_APP_BASE_API
console.log(baseApi)

// 获取省市
export async function GetCityDataJson(params) {
  return request({
    url: baseApi + 'data/GetCityDataJson',
    method: 'get',
    params
  })
}
// 获取省市=>医院
export async function GetHosPitalDataJson(params) {
  return request({
    url: baseApi + 'data/GetHosPitalDataJson',
    method: 'get',
    params
  })
}

// 新增日记浏览数
export function SetSeeCount(params) {
  return request({
    url: baseApi + 'data/SetSeeCount',
    method: 'get',
    params
  })
}

// 新增日记
export function InsertNews(params) {
  return request({
    url: baseApi + 'data/InsertNews',
    method: 'get',
    params
  })
}
// 获取医院日记列表  hosid, all = true
// all=true  就是取所有  false  取 最近5条
export function GetNewsListByHos(params) {
  return request({
    url: baseApi + 'data/GetNewsListByHos',
    method: 'get',
    params
  })
}
// 获取日记详情 ID
export function GetNewsDetail(params) {
  return request({
    url: baseApi + 'data/GetNewsDetail',
    method: 'get',
    params
  })
}
// 获取日记轮播图 id

export function GetNewsPicList(params) {
  return request({
    url: baseApi + 'data/GetNewsPicList',
    method: 'get',
    params
  })
}

// s删除图片
export function DeleteImages(params) {
  return request({
    url: baseApi + 'data/DeleteImages',
    method: 'get',
    params
  })
}
// 删除日记
export function DeleteNews(params) {
  return request({
    url: baseApi + 'data/DeleteNews',
    method: 'get',
    params
  })
}

// 分享接口
export function GetShareString(params) {
  return request({
    url: baseApi + 'data/GetShareString',
    method: 'get',
    params
  })
}

// 图片上传
export function UploadFile(data) {
  return request({
    url: baseApi + 'Plugins/UploadFile.ashx',
    method: 'post',
    data
  })
}
// 获取benner图
export function getBannerList(params) {
  return request({
    url: baseApi + 'data/GetBannerList',
    method: 'get',
    params
  })
}

// 我的日记
export function GetNewsListByMem(params) {
  return request({
    url: baseApi + 'data/GetNewsListByMem',
    method: 'get',
    params
  })
}

//坐标获取医院信息
export function GetHostpitalListByLatLng(params) {
  return request({
    url: baseApi + 'data/GetHostpitalListByLatLng',
    method: 'get',
    params
  })
}
//坐标获取医院图片
export function GetHospitalPicList(params) {
  return request({
    url: baseApi + 'data/GetHospitalPicList',
    method: 'get',
    params
  })
}
// 省市获取医院信息
export function GetHostpitalListByAddr(params) {
  return request({
    url: baseApi + 'data/GetHostpitalListByAddr',
    method: 'get',
    params
  })
}

// 获取医院
export function GetHospitalSingle(params) {
  return request({
    url: baseApi + 'data/GetHospitalSingle',
    method: 'post',
    params
  })
}
// 提交推荐医院
export function SetComments(params) {
  return request({
    url: baseApi + 'data/SetComments',
    method: 'get',
    params
  })
}
// 省市获取城市
export function GetCityList(params) {
  return request({
    url: baseApi + 'data/GetCityList',
    method: 'get',
    params
  })
}
// 获取省
export function GetProvinceList(params) {
  return request({
    url: baseApi + 'data/GetProvinceList',
    method: 'get',
    params
  })
}
// 获取医院列表
export async function GetHostPitalList(params) {
  return request({
    url: baseApi + 'data/GetHostPitalList',
    method: 'get',
    params
  })
}

// 跳转到微信
export function ReturnWechat(params) {
  return request({
    url: baseApi + 'data/ReturnWechat',
    method: 'get',
    params
  })
}
// 获取用户信息
export function GetUserInfo(params) {
  return request({
    url: baseApi + 'data/GetUserInfo',
    method: 'get',
    params
  })
}
