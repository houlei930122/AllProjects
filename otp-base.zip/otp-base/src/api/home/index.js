import request from '@/utils/request'

const baseApi = process.env.VUE_APP_BASE_MOCKAPI

// 获取首页标签栏
export function getHomeTabbar(params) {
  return request({
    url: baseApi + '/home/getTabbar',
    method: 'get',
    params
  })
}

// 获取首页轮播图
export function getHomeSwiper(params) {
  return request({
    url: baseApi + '/home/getSwiper',
    method: 'get',
    params
  })
}

// 获取首页宫格
export function getHomeGrid(params) {
  return request({
    url: baseApi + '/home/getGrid',
    method: 'get',
    params
  })
}

// 获取首页广告
export function getHomeAdvert(params) {
  return request({
    url: baseApi + '/home/getAdvert',
    method: 'get',
    params
  })
}

// 获取首页列表
export function getHomeList(params) {
  return request({
    url: baseApi + '/home/list',
    method: 'get',
    params
  })
}
