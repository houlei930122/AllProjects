import request from '@/utils/request'

const baseApi = process.env.VUE_APP_BASE_MOCKAPI

// 登录
export function login(data) {
  return request({
    url: baseApi + '/login',
    method: 'post',
    data
  })
}

// 获取用户信息
export function getInfo(data) {
  return request({
    url: baseApi + '/getInfo',
    method: 'post',
    data
  })
}

// 退出登录
export function logout(data) {
  return request({
    url: baseApi + '/logout',
    method: 'post',
    data
  })
}
