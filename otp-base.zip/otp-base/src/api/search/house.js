import request from '@/utils/request'

const baseApi = process.env.VUE_APP_BASE_MOCKAPI

// 获取首页标签栏
export function getHotSearch(params) {
  return request({
    url: baseApi + '/search/hot',
    method: 'get',
    params
  })
}