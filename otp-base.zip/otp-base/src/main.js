import Vue from 'vue'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets

import '@/styles/vant.less' // 覆盖vant的默认样式
import '@/styles/index.less' // global css

import App from './App'
import store from './store'
import router from './router'

import '@/icons' // svg icon
import '@/assets/iconfont/iconfont.css' // font-class icon
import '@/permission' // permission control
import 'lib-flexible'

import * as filters from './filters' // global filters
import md5 from 'js-md5'
Vue.prototype.$md5 = md5

import mixin from '@/utils/mixin'
Vue.mixin(mixin)

// 按需引入公共的vant组件
import {Icon, Button, Toast, Lazyload, Image as VanImage, Popup, Cascader, Field, Dialog, Empty, Loading, Sticky, NavBar, Swipe, SwipeItem, List, DropdownMenu, DropdownItem, Uploader} from 'vant'
Toast.setDefaultOptions({forbidClick: true})
Vue.use(Icon)
Vue.use(Button)
Vue.use(Toast)
Vue.use(VanImage)
Vue.use(Lazyload, {
  lazyComponent: true
})
Vue.use(Empty)
Vue.use(Dialog)
Vue.use(Loading)
Vue.use(Sticky)
Vue.use(NavBar)
Vue.use(Swipe)
Vue.use(SwipeItem)
Vue.use(List)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)
Vue.use(Uploader)
Vue.use(Cascader)
Vue.use(Field)
Vue.use(Popup)
Vue.prototype.resetUrl = function(imgurl) {
  const imgurl1 = imgurl && imgurl.replace('..', '')
  return imgurl1 && 'http://admin.m22opt.com' + imgurl1
}
import {VueJsonp} from 'vue-jsonp'
Vue.use(VueJsonp)
/**
 * If you don't want to use mock-server
 * you want to use MockJs for mock api
 * you can execute: mockXHR()
 *
 * Currently MockJs will be used in the production environment,
 * please remove it before going online ! ! !
 */
if (process.env.NODE_ENV === 'production') {
  const {mockXHR} = require('../mock')
  mockXHR()
}

// register global utility filters
Object.keys(filters).forEach((key) => {
  Vue.filter(key, filters[key])
})

Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store,
  render: (h) => h(App)
})
