const mixin = {
  data() {
    return {}
  },
  methods: {
    // 返回上一页
    backPage() {
      if (window.history.length <= 1) {
        this.$router.push({ path: '/' })
        return false
      } else {
        this.$router.go(-1)
      }
    },

    // 过滤搜索输入框中的%
    filterPercentChar(e) {
      e.target.value = e.target.value.replace(/%/g, '')
    }
  }
}
export default mixin
