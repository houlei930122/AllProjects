/**
 * Created by PanJiaChen on 16/11/18.
 */
// 分享信息
import {GetShareString} from '../api/api'

export function shareFun(title, desc, imgUrl, link) {
  const urlStr = window.location.href
  // const title = title || '干眼日记'
  const link1 = link || urlStr
  let desc1 = desc
  GetShareString({url: urlStr}).then((res) => {
    // {"appId":"wx58b379b0e151f6cb","timestamp":"1625066782","nonceStr":"0e9c703c976b4b8aa2b70932de671eb6","signature":"3b80f243ec16679c3b7a7b673fcb83cb4be562d4"}
    wx.config({debug: false, appId: res.appId, timestamp: res.timestamp, nonceStr: res.nonceStr, signature: res.signature, jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage']})
    // 微信JSSDK开发
    wx.ready(function() {
      // 分享给朋友
      wx.onMenuShareAppMessage({
        title: title, //
        desc: desc1, //
        link: link1, // 商品购买地址
        imgUrl: imgUrl, // 分享的图标
        fail: function(res) {
          // alert(JSON.stringify(res));
        }
      })

      // 分享到朋友圈
      wx.onMenuShareTimeline({
        title: title, // 商品名
        link: link1, // 商品购买地址
        imgUrl: imgUrl, // 分享的图标
        fail: function(res) {
          // alert(JSON.stringify(res));
        }
      })

      wx.updateAppMessageShareData({
        title: title, // 分享标题
        desc: desc, // 分享描述
        link: link1, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: imgUrl, // 分享图标
        success: function() {
          // 设置成功
        }
      })
      wx.updateTimelineShareData({
        title: '', // 分享标题
        link: '', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: '', // 分享图标
        success: function() {
          // 设置成功
        }
      })
    })
  })
}

/**
 * Parse the time to string 日期格式化
 * @param {(Object|string|number)} time
 * @param {string} cFormat
 * @returns {string | null}
 */
export function parseTime(time, cFormat) {
  if (arguments.length === 0 || !time) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if (typeof time === 'string') {
      if (/^[0-9]+$/.test(time)) {
        // support "1548221490638"
        time = parseInt(time)
      } else {
        // support safari
        // https://stackoverflow.com/questions/4310953/invalid-date-in-safari
        time = time.replace(new RegExp(/-/gm), '/')
      }
    }

    if (typeof time === 'number' && time.toString().length === 10) {
      time = time * 1000
    }
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  }
  const time_str = format.replace(/{([ymdhisa])+}/g, (result, key) => {
    const value = formatObj[key]
    // Note: getDay() returns 0 on Sunday
    if (key === 'a') {
      return ['日', '一', '二', '三', '四', '五', '六'][value]
    }
    return value.toString().padStart(2, '0')
  })
  return time_str
}

/**
 * 评论时间格式化
 * @param {number} time
 * @param {string} option
 * @returns {string}
 */
export function formatTime(time, option) {
  if (('' + time).length === 10) {
    time = parseInt(time) * 1000
  } else {
    time = +time
  }
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) {
    // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
  }
}

/**
 * 获取url后面的参数
 * @param {string} url
 * @returns {Object}
 */
export function param2Obj(url) {
  const search = decodeURIComponent(url.split('?')[1]).replace(/\+/g, ' ')
  if (!search) {
    return {}
  }
  const obj = {}
  const searchArr = search.split('&')
  searchArr.forEach((v) => {
    const index = v.indexOf('=')
    if (index !== -1) {
      const name = v.substring(0, index)
      const val = v.substring(index + 1, v.length)
      obj[name] = val
    }
  })
  return obj
}

/**
 * 防抖函数
 * @param {Function} func
 * @param {number} wait
 * @param {boolean} immediate
 * @return {*}
 */
export function debounce(func, wait, immediate) {
  let timeout, args, context, timestamp, result

  const later = function() {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp

    // 上次被包装函数被调用时间间隔 last 小于设定时间间隔 wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args)
        if (!timeout) context = args = null
      }
    }
  }

  return function(...args) {
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = args = null
    }

    return result
  }
}

/**
 * 节流函数
 * @param {Function} func
 * @param {number} delay
 * @return {*}
 */

export function throttle(fn, delay) {
  var lastTime
  var timer
  delay = delay || 200
  return function(...args) {
    // 记录当前函数触发的时间
    var nowTime = Date.now()
    if (lastTime && nowTime - lastTime < delay) {
      clearTimeout(timer)
      timer = setTimeout(() => {
        // 记录上一次函数触发的时间
        lastTime = nowTime
        // 修正this指向问题
        fn.apply(this, args)
      }, delay)
    } else {
      lastTime = nowTime
      fn.apply(this, args)
    }
  }
}

/**
 * 深拷贝
 * Has a lot of edge cases bug
 * If you want to use a perfect deep copy, use lodash's _.cloneDeep
 * @param {Object} source
 * @returns {Object}
 */
export function deepClone(source) {
  if (!source && typeof source !== 'object') {
    throw new Error('error arguments', 'deepClone')
  }
  const targetObj = source.constructor === Array ? [] : {}
  Object.keys(source).forEach((keys) => {
    if (source[keys] && typeof source[keys] === 'object') {
      targetObj[keys] = deepClone(source[keys])
    } else {
      targetObj[keys] = source[keys]
    }
  })
  return targetObj
}

/**
 *  判断是否为空
 *  @param {?All} 任意值
 *  @return {boolean}
 *  例：isEmpty(element.children)
 */
export function isEmpty(obj) {
  if (typeof obj === 'undefined' || obj === null || obj === '' || obj === 'undefined' || obj === 'null' || JSON.stringify(obj) === '[]' || JSON.stringify(obj) === '{}') {
    return false
  } else {
    return true
  }
}

/**
 * 遍历后台返回的对象数组格式的菜单或分类数据，添加层级属性，删除空的children属性
 * @param {Array} data
 * @param {number} level
 * @return {null}
 */
export function addLevel(data, level = 1) {
  if (!data) {
    return false
  }
  data.forEach((v) => {
    v.level = level
    if (isEmpty(v.children)) {
      addLevel(v.children, level + 1)
    } else {
      delete v.children
    }
  })
}

/**
 *  通过id查找完整的父级id数组
 *  @param {Number} key - 父级id
 *  @param {Object} treeData - 分类数据
 *  @param {boolean} flag - 默认为不删除最后一层，传入true删除最后一层
 *  @return {Array}
 *  例：getTreeDeepArr(data.id,this.cateList);
 */
export function getTreeDeepArr(key, treeData, flag) {
  const arr = [] // 在递归时操作的数组
  let returnArr = [] // 存放结果的数组
  let depth = 0 // 定义全局层级
  function truncate(arr) {
    return arr.filter((v, i, ar) => i !== ar.length - 1)
  }
  // 定义递归函数
  function childrenEach(childrenData, depthN) {
    for (let j = 0; j < childrenData.length; j++) {
      depth = depthN // 将执行的层级赋值 到 全局层级
      arr[depthN] = childrenData[j].id
      // eslint-disable-next-line eqeqeq
      if (childrenData[j].id == key) {
        // returnArr = arr; // 原写法不行, 因此赋值存在指针关系
        returnArr = arr.slice(0, depthN + 1) // 将目前匹配的数组，截断并保存到结果数组，
        break
      } else {
        if (childrenData[j].children) {
          depth++
          childrenEach(childrenData[j].children, depth)
        }
      }
    }
    return returnArr
  }
  if (flag) {
    return truncate(childrenEach(treeData, depth))
  } else {
    return childrenEach(treeData, depth)
  }
}

/**
 *  比较编辑表单提交前后的数据是否一致
 *  @param {Object} newVal - 修改后的数据
 *  @param {Object} oldVal - 原始数据
 *  @return {Boolean}
 */
export function isDiffForm(newVal, oldVal) {
  for (const k in oldVal) {
    // eslint-disable-next-line eqeqeq
    if (oldVal[k] != newVal[k]) {
      return true
    }
  }
}
