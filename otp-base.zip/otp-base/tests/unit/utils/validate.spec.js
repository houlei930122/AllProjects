import { validUsernameOld, isExternal } from '@/utils/validate.js'

describe('Utils:validate', () => {
  it('validUsernameOld', () => {
    expect(validUsernameOld('admin')).toBe(true)
    expect(validUsernameOld('editor')).toBe(true)
    expect(validUsernameOld('xxxx')).toBe(false)
  })
  it('isExternal', () => {
    expect(isExternal('https://github.com/PanJiaChen/vue-element-admin')).toBe(true)
    expect(isExternal('http://github.com/PanJiaChen/vue-element-admin')).toBe(true)
    expect(isExternal('github.com/PanJiaChen/vue-element-admin')).toBe(false)
    expect(isExternal('/dashboard')).toBe(false)
    expect(isExternal('./dashboard')).toBe(false)
    expect(isExternal('dashboard')).toBe(false)
  })
})
