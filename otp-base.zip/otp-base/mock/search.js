const Mock = require('mockjs')

const hot = { '2': [], '3': [], '4': [], '5': [] }

for (let i = 0; i < 10; i++) {
  hot['2'].push(
    Mock.mock({
      id: '@increment(1)',
      name: '@ctitle(2,5)'
    })
  )
  hot['3'].push(
    Mock.mock({
      id: '@increment(1)',
      name: '@ctitle(2,5)'
    })
  )
  hot['4'].push(
    Mock.mock({
      id: '@increment(1)',
      name: '@ctitle(2,5)'
    })
  )
  hot['5'].push(
    Mock.mock({
      id: '@increment(1)',
      name: '@ctitle(2,5)'
    })
  )
}

module.exports = [
  // 获取热门搜索
  {
    url: '/search/hot',
    type: 'get',
    response: (config) => {
      const { type } = config.query
      let list = {}
      if (type && type !== '1') {
        for (const key in hot) {
          if (key === type) {
            list[type] = hot[key]
          }
        }
      } else {
        list = hot
      }
      return {
        code: '00',
        message: '热门搜索查询成功',
        data: list
      }
    }
  }
]
