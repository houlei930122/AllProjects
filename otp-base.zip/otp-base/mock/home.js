const Mock = require('mockjs')

const types = [
  {
    id: '1',
    name: '推荐'
  },
  {
    id: '2',
    name: '新房'
  },
  {
    id: '3',
    name: '二手房'
  },
  {
    id: '4',
    name: '商用房'
  },
  {
    id: '5',
    name: '装修'
  }
]
const list = []
const listTotal = 1000

for (let i = 0; i < listTotal; i++) {
  list.push(
    Mock.mock({
      id: '@increment(1)',
      title: '@ctitle(5,10)',
      'totalPrice|50-200': 200,
      'averagePrice|5000-20000': 20000,
      'type|1': types,
      typeId: function() {
        return this.type.id
      }
    })
  )
}

module.exports = [
  // 获取 标签页
  {
    url: '/home/getTabbar',
    type: 'get',
    response: (_) => {
      return {
        code: '00',
        message: '获取首页标签栏数据成功',
        data: [
          {
            path: '/',
            title: '首页',
            inactive: 'images/common/home_tabbar/home.png',
            active: 'images/common/home_tabbar/home_active.png'
          },
          {
            path: '/message',
            title: '消息',
            inactive: 'images/common/home_tabbar/message.png',
            active: 'images/common/home_tabbar/message_active.png'
          },
          {
            path: '/community',
            title: '有料',
            inactive: 'images/common/home_tabbar/community.png',
            active: 'images/common/home_tabbar/community_active.png'
          },
          {
            path: '/finance',
            title: '金融',
            inactive: 'images/common/home_tabbar/finance.png',
            active: 'images/common/home_tabbar/finance_active.png'
          },
          {
            path: '/mine',
            title: '我的',
            inactive: 'images/common/home_tabbar/mine.png',
            active: 'images/common/home_tabbar/mine_active.png'
          }
        ]
      }
    }
  },
  // 获取 轮播图
  {
    url: '/home/getSwiper',
    type: 'get',
    response: (_) => {
      return {
        code: '00',
        message: '获取首页轮播图数据成功',
        data: [
          {
            title: '首页轮播图1',
            imgUrl: 'images/home/swiper_1.png'
          }
        ]
      }
    }
  },
  // 获取 宫格
  {
    url: '/home/getGrid',
    type: 'get',
    response: (_) => {
      return {
        code: '00',
        message: '获取首页宫格数据成功',
        data: [
          {
            id: 1,
            path: '/house/list?type=2',
            title: '新房',
            imgUrl: 'images/home/grid_1.png'
          },
          {
            id: 2,
            path: '',
            title: '二手房',
            imgUrl: 'images/home/grid_2.png'
          },
          {
            id: 3,
            path: '',
            title: '商铺写字楼',
            imgUrl: 'images/home/grid_3.png'
          },
          {
            id: 4,
            path: '',
            title: '查房价',
            imgUrl: 'images/home/grid_4.png'
          },
          {
            id: 5,
            path: '',
            title: 'VR看房',
            imgUrl: 'images/home/grid_5.png'
          },
          {
            id: 6,
            path: '',
            title: '我是业主',
            imgUrl: 'images/home/grid_6.png'
          },
          {
            id: 7,
            path: '',
            title: '地图找房',
            imgUrl: 'images/home/grid_7.png'
          },
          {
            id: 8,
            path: '',
            title: '卖房',
            imgUrl: 'images/home/grid_8.png'
          },
          {
            id: 9,
            path: '',
            title: '房贷计算',
            imgUrl: 'images/home/grid_9.png'
          },
          {
            id: 10,
            path: '',
            title: '税费计算',
            imgUrl: 'images/home/grid_10.png'
          },
          {
            id: 11,
            path: '',
            title: '购房百科',
            imgUrl: 'images/home/grid_11.png'
          },
          {
            id: 12,
            path: '',
            title: '房源对比',
            imgUrl: 'images/home/grid_12.png'
          },
          {
            id: 13,
            path: '',
            title: '房产估价',
            imgUrl: 'images/home/grid_13.png'
          },
          {
            id: 14,
            path: '',
            title: '生活缴费',
            imgUrl: 'images/home/grid_14.png'
          },
          {
            id: 15,
            path: '',
            title: '市场行情',
            imgUrl: 'images/home/grid_15.png'
          },
          {
            id: 16,
            path: '',
            title: '楼讯',
            imgUrl: 'images/home/grid_16.png'
          },
          {
            id: 17,
            path: '',
            title: '资讯',
            imgUrl: 'images/home/grid_17.png'
          },
          {
            id: 18,
            path: '',
            title: '问答',
            imgUrl: 'images/home/grid_18.png'
          },
          {
            id: 19,
            path: '',
            title: '论坛',
            imgUrl: 'images/home/grid_19.png'
          },
          {
            id: 20,
            path: '',
            title: '装修',
            imgUrl: 'images/home/grid_20.png'
          }
        ]
      }
    }
  },
  // 获取 广告
  {
    url: '/home/getAdvert',
    type: 'get',
    response: (_) => {
      return {
        code: '00',
        message: '获取首页广告数据成功',
        data: [
          {
            id: 1,
            path: '',
            title: '降价急售 机会只有一次',
            subTitle: '二环内近地铁三居房，降价首付23万元起...',
            imgUrl: 'images/home/advert_1.png'
          },
          {
            id: 2,
            path: '',
            title: '广告信息',
            subTitle: '二环内近地铁四居房，降价首付33万元起...',
            imgUrl: 'images/home/advert_1.png'
          }
        ]
      }
    }
  },
  // 获取房源列表
  {
    url: '/home/list',
    type: 'get',
    response: (config) => {
      const { type, title, page = 1, limit = 10 } = config.query
      const mockList = list.filter((item) => {
        if (type && item.typeId !== type) return false
        if (title && item.title.indexOf(title) < 0) return false
        return true
      })

      const pageList = mockList.filter((item, index) => index < limit * page && index >= limit * (page - 1))

      for (const item of pageList) {
        for (const type of types) {
          if (item.typeId === type.id) {
            item.typeName = type.name
          }
        }
      }
      return {
        code: '00',
        message: '列表查询成功',
        data: { records: pageList, total: mockList.length, page: +page, limit: +limit }
      }
    }
  }
]
