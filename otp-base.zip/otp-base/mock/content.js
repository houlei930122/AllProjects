const Mock = require('mockjs')

const tags = []
let tagsTotal = 6

for (let i = 0; i < tagsTotal; i++) {
  tags.push(Mock.mock({
    id: '@increment(1)',
    name: '@ctitle(2,5)',
    description: '@csentence(10,50)'
  }))
}

const list = []
let listTotal = 132

for (let i = 0; i < listTotal; i++) {
  list.push(Mock.mock({
    id: '@increment(1)',
    title: '@ctitle(5,50)',
    'tag|1': tags,
    tagId: function() { return this.tag.id },
    source: '@city',
    author: '@cname',
    content: '@cparagraph',
    crtTm: '@now("yyyy-MM-dd HH:mm:ss")',
    modTm: '@now("yyyy-MM-dd HH:mm:ss")',
    'status|1': ['0', '1', '2']
  }))
}

module.exports = [
  // mock 获取分类列表
  {
    url: '/dataDic/pageList',
    type: 'post',
    response: _ => {
      return {
        code: '00',
        message: '列表查询成功',
        data: { records: tags }
      }
    }
  },

  // 查询分类
  {
    url: '/content/getOneTag',
    type: 'get',
    response: config => {
      const { id } = config.query
      const tag = tags.filter(v => v.id === +id)[0]
      return {
        code: '00',
        message: '查询成功',
        data: tag
      }
    }
  },

  // 添加分类
  {
    url: '/content/addTags',
    type: 'post',
    response: config => {
      const { name, description } = config.body
      tags.unshift({
        id: Mock.mock('@increment(1)'),
        name,
        description
      })
      tagsTotal++
      return {
        code: '00',
        message: '添加成功',
        data: null
      }
    }
  },

  // 更新分类
  {
    url: '/content/updateTags',
    type: 'post',
    response: config => {
      const { id, name, description } = config.body
      const index = tags.findIndex(v => v.id === +id)
      tags.splice(index, 1, { id, name, description })
      return {
        code: '00',
        message: '更新成功',
        data: null
      }
    }
  },

  // 删除分类
  {
    url: '/content/deleteTags',
    type: 'get',
    response: config => {
      const { id } = config.query
      const index = tags.findIndex(v => v.id === +id)
      tags.splice(index, 1)
      tagsTotal--
      return {
        code: '00',
        message: '删除成功',
        data: null
      }
    }
  },

  // mock 获取文章列表
  {
    url: '/content/pageList',
    type: 'post',
    response: config => {
      const { title, tagId, page = 1, limit = 10 } = config.body

      const mockList = list.filter(item => {
        if (tagId && item.tagId !== +tagId) return false
        if (title && item.title.indexOf(title) < 0) return false
        return true
      })

      const pageList = mockList.filter((item, index) => index < limit * page && index >= limit * (page - 1))

      for (const article of pageList) {
        for (const tag of tags) {
          if (+article.tagId === tag.id) {
            article.tagName = tag.name
          }
        }
      }
      return {
        code: '00',
        message: '列表查询成功',
        data: { records: pageList, total: mockList.length }
      }
    }
  },

  // 添加文章
  {
    url: '/content/add',
    type: 'post',
    response: config => {
      const { title, tagId, source, author, content, status } = config.body
      list.unshift({
        id: Mock.mock('@increment(1)'),
        title,
        tagId,
        source,
        author,
        content,
        status,
        crtTm: '@now("yyyy-MM-dd HH:mm:ss")',
        modTm: '@now("yyyy-MM-dd HH:mm:ss")'
      })
      listTotal++
      return {
        code: '00',
        message: '添加成功',
        data: null
      }
    }
  },

  // 查询文章
  {
    url: '/content/[A-Za-z0-9]',
    type: 'get',
    response: config => {
      const { id } = config.query
      const article = list.filter(v => v.id === +id)[0]
      return {
        code: '00',
        message: '查询成功',
        data: article
      }
    }
  },

  // 更新文章
  {
    url: '/content/[A-Za-z0-9]',
    type: 'put',
    response: config => {
      const { id, title, tagId, source, author, content, status } = config.body
      const index = list.findIndex(v => v.id === +id)
      list.splice(index, 1, { id, title, tagId, source, author, content, status, modTm: '@now("yyyy-MM-dd HH:mm:ss")' })
      return {
        code: '00',
        message: '更新成功',
        data: null
      }
    }
  },

  // 删除分类
  {
    url: '/content/[A-Za-z0-9]',
    type: 'delete',
    response: config => {
      const { id } = config.query
      const index = list.findIndex(v => v.id === +id)
      list.splice(index, 1)
      listTotal--
      return {
        code: '00',
        message: '删除成功',
        data: null
      }
    }
  }
]
