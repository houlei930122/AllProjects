module.exports = [
  // mock 登录接口
  {
    url: '/login',
    type: 'post',
    response: (config) => {
      const { username, password } = config.body
      if (username === 'admin' && password === '111111') {
        return {
          code: '00',
          message: '登录成功',
          data: 'dw125tfwced21t13rqw2dq2w3t2t32'
        }
      } else {
        return {
          code: '01',
          message: '用户名或密码错误',
          data: null
        }
      }
    }
  }
]
